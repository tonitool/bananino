const { contextBridge, ipcRenderer } = require('electron')

const IPC = {
  recorderBegin: 'recorder:begin',
  recorderEnd: 'recorder:end',
  recorderChunk: 'recorder:chunk',
  recorderStatus: 'recorder:status',
}

contextBridge.exposeInMainWorld('recorder', {
  onBegin: (handler) => ipcRenderer.on(IPC.recorderBegin, (_event, options) => handler(options)),
  onEnd: (handler) => ipcRenderer.on(IPC.recorderEnd, () => handler()),
  chunk: (track, samples) => ipcRenderer.send(IPC.recorderChunk, { track, samples }),
  status: (status) => ipcRenderer.send(IPC.recorderStatus, status),
})

import { el, clear, setHidden } from '../dom.js'
import { formatElapsed } from '../format.js'

const TICK_MS = 1000

/**
 * Recording is always a deliberate act here: there is a button, never an automatic start.
 * The state is also made loud — a pulsing dot and a live clock — because a recorder you
 * can forget about is a problem, not a feature.
 */
export const createMeetingTab = ({ onStart, onStop, onOpen, onDismiss }) => {
  const title = el('input', {
    class: 'meeting-title',
    type: 'text',
    placeholder: 'Meeting name (optional)',
    'aria-label': 'Meeting name',
    autocomplete: 'off',
  })

  const recordButton = el('button', {
    class: 'button button--record',
    type: 'button',
    text: 'Record',
    onclick: () => onStart(title.value),
  })

  const idle = el('div', { class: 'meeting-idle' }, [
    el('div', { class: 'meeting-entry' }, [title, recordButton]),
  ])

  const clock = el('span', { class: 'timer-clock', text: '00:00' })
  const runningTitle = el('span', { class: 'timer-task' })
  const running = el('div', { class: 'meeting-running' }, [
    el('div', { class: 'timer-readout' }, [
      el('span', { class: 'rec-line' }, [el('span', { class: 'rec-dot' }), clock]),
      runningTitle,
    ]),
    el('button', {
      class: 'button button--stop',
      type: 'button',
      text: 'Stop',
      onclick: onStop,
    }),
  ])

  const step = el('p', { class: 'meeting-step' })
  const processing = el('div', { class: 'meeting-processing' }, [
    el('span', { class: 'spinner', 'aria-hidden': 'true' }),
    step,
  ])

  const errorText = el('p', { class: 'meeting-error-text' })
  const failed = el('div', { class: 'meeting-failed' }, [
    errorText,
    el('button', { class: 'button button--quiet', type: 'button', text: 'Dismiss', onclick: onDismiss }),
  ])

  const tools = el('p', { class: 'hint meeting-tools' })
  const recent = el('ul', { class: 'recent', 'aria-label': 'Recent meetings' })

  const stage = el('section', { class: 'meeting-stage' }, [idle, running, processing, failed])
  const root = el('section', { class: 'tab-panel', id: 'tab-meet', role: 'tabpanel' }, [
    stage,
    tools,
    el('h2', { class: 'section-title', text: 'Recent meetings' }),
    recent,
  ])

  let startedAt = null

  const tick = () => {
    if (startedAt === null) return
    clock.textContent = formatElapsed(Date.now() - startedAt)
  }
  setInterval(tick, TICK_MS)

  const update = ({ meeting, recentMeetings, tools: available }) => {
    const status = meeting?.status ?? 'idle'
    stage.dataset.state = status
    startedAt = status === 'recording' ? meeting.startedAt : null

    setHidden(idle, status !== 'idle')
    setHidden(running, status !== 'recording')
    setHidden(processing, status !== 'processing')
    setHidden(failed, status !== 'error')

    if (status === 'recording') {
      runningTitle.textContent = meeting.title || 'Untitled meeting'
      tick()
    }
    if (status === 'processing') step.textContent = meeting.step ?? 'Working…'
    if (status === 'error') errorText.textContent = meeting.message ?? 'Something went wrong.'
    if (status === 'idle') title.value = title.value

    renderTools(available)
    renderRecent(recentMeetings ?? [])
  }

  /** Missing tooling is surfaced before a recording, not after an hour of audio. */
  function renderTools(available) {
    if (!available) return void (tools.textContent = '')
    const problems = [available.transcriber, available.llm].filter((tool) => tool && !tool.ok)

    if (problems.length === 0) {
      tools.textContent = `Local: ${available.transcriber?.model ?? 'whisper'} · ${
        available.llm?.model ?? 'ollama'
      }`
      tools.dataset.tone = 'ok'
      return
    }
    tools.textContent = problems.map((tool) => `${tool.reason} ${tool.hint ?? ''}`.trim()).join(' · ')
    tools.dataset.tone = 'warn'
  }

  function renderRecent(meetings) {
    clear(recent)
    if (meetings.length === 0) {
      recent.append(el('li', { class: 'empty', text: 'No meetings recorded yet.' }))
      return
    }
    for (const meeting of meetings) {
      recent.append(
        el('li', { class: 'recent-item' }, [
          el('button', {
            class: 'clip-body',
            type: 'button',
            title: 'Open this meeting note',
            onclick: () => onOpen(meeting.notePath ?? meeting.path),
          }, [
            el('span', { class: 'clip-text', text: meeting.name }),
            el('span', {
              class: 'clip-meta',
              text: meeting.notePath ? 'note ready' : 'audio only',
            }),
          ]),
        ]),
      )
    }
  }

  return { root, update, focus: () => title.focus() }
}

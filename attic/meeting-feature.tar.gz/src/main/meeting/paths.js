import { access, mkdir, readdir } from 'node:fs/promises'
import { homedir } from 'node:os'
import { join } from 'node:path'
import { WHISPER } from '../constants.js'
import { isoDate } from '../storage/dates.js'

const pad = (n) => String(n).padStart(2, '0')

export const meetingsDir = (dataDir) => join(dataDir, 'meetings')

/** Slug kept conservative: these become folder names on a case-insensitive filesystem. */
export const slugify = (title) =>
  String(title ?? '')
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48)

export const sessionFolderName = (title, at) => {
  const stamp = `${isoDate(at)}-${pad(at.getHours())}${pad(at.getMinutes())}`
  const slug = slugify(title)
  return slug ? `${stamp}-${slug}` : stamp
}

export const createSessionDir = async ({ dataDir, title, at }) => {
  const dir = join(meetingsDir(dataDir), sessionFolderName(title, at))
  await mkdir(dir, { recursive: true })
  return dir
}

const expandHome = (path) => (path.startsWith('~') ? join(homedir(), path.slice(1)) : path)

const exists = (path) =>
  access(path).then(
    () => true,
    () => false,
  )

/**
 * Finds an installed whisper.cpp model rather than shipping one — they are 0.5–3 GB.
 * `LUALALA_WHISPER_MODEL` overrides the search entirely.
 */
export const findWhisperModel = async () => {
  const override = process.env.LUALALA_WHISPER_MODEL
  if (override) return (await exists(override)) ? override : null

  for (const dir of WHISPER.modelDirs) {
    const resolved = expandHome(dir)
    const entries = await readdir(resolved).catch(() => null)
    if (!entries) continue

    for (const preferred of WHISPER.modelPreference) {
      const match = entries.find((name) => name === `${preferred}.bin`)
      if (match) return join(resolved, match)
    }
  }
  return null
}

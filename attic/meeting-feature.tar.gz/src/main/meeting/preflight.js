import { OLLAMA } from '../constants.js'
import { checkOllama } from './llm.js'
import { checkTranscriber } from './transcribe.js'

const CACHE_MS = 60_000

const basename = (path) => path?.split('/').pop() ?? null

/**
 * Both checks spawn a process or make a request, so results are cached briefly. Recording
 * forces a fresh look — being told an hour later that whisper was missing is no use.
 */
export const createPreflight = ({ getSettings }) => {
  let cached = null
  let checkedAt = 0

  const inspect = async () => {
    const model = getSettings().llmModel || OLLAMA.defaultModel
    const [transcriber, llm] = await Promise.all([checkTranscriber(), checkOllama(model)])

    return {
      transcriber: { ...transcriber, model: basename(transcriber.model) },
      llm: { ...llm, model },
    }
  }

  const get = async ({ force = false } = {}) => {
    if (!force && cached && Date.now() - checkedAt < CACHE_MS) return cached
    cached = await inspect()
    checkedAt = Date.now()
    return cached
  }

  return { get, invalidate: () => (cached = null) }
}

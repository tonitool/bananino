import { BrowserWindow, desktopCapturer, session } from 'electron'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'
import { IPC, MEETING } from '../constants.js'

const here = dirname(fileURLToPath(import.meta.url))
const PRELOAD = join(here, '..', '..', 'preload', 'recorder.cjs')
const PAGE = join(here, '..', '..', '..', 'build', 'recorder.html')

/**
 * Audio capture lives in its own hidden window: `getDisplayMedia` and AudioWorklet are web
 * APIs, and keeping them out of the character's window means a long recording never
 * competes with the render loop.
 */
export const createRecorderWindow = () => {
  const win = new BrowserWindow({
    show: false,
    width: 320,
    height: 200,
    webPreferences: {
      preload: PRELOAD,
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      backgroundThrottling: false,
    },
  })

  win.loadFile(PAGE)

  const begin = ({ withMic = true } = {}) =>
    win.webContents.send(IPC.recorderBegin, {
      sampleRate: MEETING.sampleRate,
      chunkFrames: MEETING.chunkFrames,
      withMic,
    })

  const end = () => win.webContents.send(IPC.recorderEnd)

  return { win, begin, end }
}

/**
 * Answers the renderer's getDisplayMedia call with system audio loopback.
 *
 * The video source is required to open the ScreenCaptureKit stream even though only the
 * audio is wanted; the recorder stops the video track immediately. Note that without
 * `NSAudioCaptureUsageDescription` in Info.plist macOS returns a silent, dead audio
 * stream with no error at all — see the entitlements in package.json.
 */
export const registerDisplayMediaHandler = () => {
  session.defaultSession.setDisplayMediaRequestHandler(
    (_request, callback) => {
      desktopCapturer
        .getSources({ types: ['screen'], fetchWindowIcons: false })
        .then((sources) => {
          if (sources.length === 0) {
            console.warn('[meeting] no screen source — screen recording permission?')
            return callback({})
          }
          callback({ video: sources[0], audio: 'loopback' })
        })
        .catch((error) => {
          console.error('[meeting] could not enumerate screen sources:', error)
          callback({})
        })
    },
    // The system picker would put a dialog in front of the user on every recording.
    { useSystemPicker: false },
  )
}

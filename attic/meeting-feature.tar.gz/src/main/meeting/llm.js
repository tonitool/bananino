import { OLLAMA } from '../constants.js'

export class LlmUnavailable extends Error {
  constructor(message, { hint } = {}) {
    super(message)
    this.name = 'LlmUnavailable'
    this.hint = hint
  }
}

/** Reasoning models leak their scratchpad if asked nicely; strip it either way. */
const stripThinking = (text) =>
  text
    .replace(/<think>[\s\S]*?<\/think>/gi, '')
    .replace(/^\s*<\/?think>\s*$/gim, '')
    .trim()

export const checkOllama = async (model) => {
  try {
    const response = await fetch(`${OLLAMA.url}/api/tags`, { signal: AbortSignal.timeout(4000) })
    if (!response.ok) throw new Error(`HTTP ${response.status}`)

    const names = (await response.json()).models?.map((entry) => entry.name) ?? []
    const installed = names.some((name) => name === model || name.split(':')[0] === model)

    if (!installed) {
      return {
        ok: false,
        reason: `Ollama is running but "${model}" is not installed.`,
        hint: `ollama pull ${model}`,
        available: names,
      }
    }
    return { ok: true, available: names }
  } catch (error) {
    return {
      ok: false,
      reason: `Ollama is not reachable at ${OLLAMA.url}.`,
      hint: 'Start it with: ollama serve',
      cause: error.message,
    }
  }
}

/**
 * One non-streaming chat turn. Everything here runs on the machine that recorded the
 * meeting, which is the whole point — the transcript never leaves it.
 */
export const ask = async ({ model, system, prompt, signal }) => {
  const response = await fetch(`${OLLAMA.url}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    signal: signal ?? AbortSignal.timeout(OLLAMA.timeoutMs),
    body: JSON.stringify({
      model,
      stream: false,
      think: false,
      options: { temperature: 0.2 },
      messages: [
        ...(system ? [{ role: 'system', content: system }] : []),
        { role: 'user', content: prompt },
      ],
    }),
  })

  if (!response.ok) {
    const detail = await response.text().catch(() => '')
    throw new LlmUnavailable(`Ollama returned HTTP ${response.status}. ${detail}`.trim())
  }

  const body = await response.json()
  if (body.error) throw new LlmUnavailable(body.error)

  return stripThinking(body.message?.content ?? '')
}

import { execFile } from 'node:child_process'
import { promisify } from 'node:util'

const run = promisify(execFile)

const POLL_INTERVAL_MS = 8000

/**
 * Zoom spawns a separate `CptHost` process only while you are actually in a meeting,
 * which makes it the one signal here that is not a guess. Teams, Webex and Slack run all
 * day whether or not you are in a call, and the clean signal — is the microphone live —
 * needs a native helper this app does not have. So detection covers Zoom, and everything
 * else uses the button.
 */
const IN_MEETING_PROCESSES = Object.freeze([{ process: 'CptHost', label: 'Zoom' }])

const isRunning = async (name) => {
  try {
    await run('pgrep', ['-x', name], { timeout: 4000 })
    return true
  } catch {
    // pgrep exits 1 when nothing matched, which is not an error here.
    return false
  }
}

export const detectMeeting = async () => {
  for (const candidate of IN_MEETING_PROCESSES) {
    if (await isRunning(candidate.process)) return candidate
  }
  return null
}

/**
 * Fires `onJoined` once per call, never repeatedly, and only ever *offers* — the decision
 * to record stays with the user.
 */
export const watchForMeetings = ({ onJoined, isEnabled = () => true }) => {
  let previous = null

  const tick = async () => {
    if (!isEnabled()) return
    const current = await detectMeeting()

    if (current && !previous) onJoined?.(current)
    previous = current
  }

  const timer = setInterval(() => {
    tick().catch((error) => console.warn('[meeting] detection failed:', error.message))
  }, POLL_INTERVAL_MS)

  return () => clearInterval(timer)
}

import { execFile } from 'node:child_process'
import { readFile, unlink } from 'node:fs/promises'
import { promisify } from 'node:util'
import { WHISPER } from '../constants.js'
import { findWhisperModel } from './paths.js'

const run = promisify(execFile)

const TRANSCRIBE_TIMEOUT_MS = 30 * 60 * 1000

export class TranscriptionUnavailable extends Error {
  constructor(message, { hint } = {}) {
    super(message)
    this.name = 'TranscriptionUnavailable'
    this.hint = hint
  }
}

/** Checked before recording so a missing tool is reported up front, not an hour later. */
export const checkTranscriber = async () => {
  const model = await findWhisperModel()
  const binary = await run(WHISPER.binary, ['--help'], { timeout: 15_000 }).then(
    () => WHISPER.binary,
    () => null,
  )

  if (!binary) {
    return {
      ok: false,
      reason: `${WHISPER.binary} is not on PATH.`,
      hint: 'brew install whisper-cpp',
    }
  }
  if (!model) {
    return {
      ok: false,
      reason: 'No whisper model was found.',
      hint: `Put a ggml-*.bin in ${WHISPER.modelDirs[1]}, or set LUALALA_WHISPER_MODEL.`,
    }
  }
  return { ok: true, binary, model }
}

/**
 * Runs whisper.cpp over one WAV and returns timestamped segments.
 *
 * Language is auto-detected rather than assumed: a German meeting with English product
 * names is the normal case here, and forcing a language makes that worse, not better.
 */
export const transcribeFile = async ({ wavPath, outputBase, signal }) => {
  const check = await checkTranscriber()
  if (!check.ok) throw new TranscriptionUnavailable(check.reason, { hint: check.hint })

  const args = [
    '-m', check.model,
    '-f', wavPath,
    '-l', 'auto',
    '-oj',
    '-of', outputBase,
    '-np',
  ]

  await run(check.binary, args, { timeout: TRANSCRIBE_TIMEOUT_MS, signal, maxBuffer: 64 * 1024 * 1024 })

  const jsonPath = `${outputBase}.json`
  const parsed = JSON.parse(await readFile(jsonPath, 'utf8'))
  await unlink(jsonPath).catch(() => {})

  return {
    language: parsed?.result?.language ?? 'unknown',
    segments: (parsed?.transcription ?? [])
      .map((entry) => ({
        fromMs: Number(entry?.offsets?.from) || 0,
        toMs: Number(entry?.offsets?.to) || 0,
        text: String(entry?.text ?? '').trim(),
      }))
      .filter((segment) => segment.text !== ''),
  }
}

/** Interleaves the two tracks into one speaker-labelled script, ordered by time. */
export const mergeTracks = (tracks) =>
  tracks
    .flatMap(({ speaker, result }) =>
      result.segments.map((segment) => ({ ...segment, speaker, language: result.language })),
    )
    .sort((a, b) => a.fromMs - b.fromMs || (a.speaker === 'Me' ? -1 : 1))

import { join } from 'node:path'
import { MEETING } from '../constants.js'
import { createWavWriter } from './wav.js'
import { createSessionDir } from './paths.js'

export const TRACK_SPEAKERS = Object.freeze({ mic: 'Me', system: 'Others' })

/** Read aloud in warnings, where "the me track" would be nonsense. */
export const TRACK_NAMES = Object.freeze({
  mic: 'your microphone',
  system: "the other participants'",
})

/**
 * One recording at a time, with a track written straight to disk per audio source.
 *
 * Recording never begins on its own. Detection can offer, the shortcut can ask, but the
 * transition into `recording` always comes from an explicit instruction — which for
 * meetings is a legal requirement in Germany, not a nicety.
 */
export const createMeetingSession = ({ getSettings, onState }) => {
  let state = { status: 'idle' }
  let writers = new Map()
  let chunkCounts = new Map()

  const publish = (next) => {
    state = next
    onState?.(state)
    return state
  }

  const start = async ({ title }) => {
    if (state.status !== 'idle') throw new Error('A recording is already in progress.')

    const startedAt = new Date()
    const dir = await createSessionDir({ dataDir: getSettings().dataDir, title, at: startedAt })

    writers = new Map()
    chunkCounts = new Map()
    for (const track of Object.keys(TRACK_SPEAKERS)) {
      writers.set(
        track,
        await createWavWriter({
          path: join(dir, `${track}.wav`),
          sampleRate: MEETING.sampleRate,
        }),
      )
    }

    return publish({ status: 'recording', title, startedAt: startedAt.getTime(), dir })
  }

  /** Chunks are fire-and-forget from the recorder; the writer serialises them. */
  const appendChunk = (track, samples) => {
    if (state.status !== 'recording') return
    const writer = writers.get(track)
    if (!writer) return
    chunkCounts.set(track, (chunkCounts.get(track) ?? 0) + 1)
    writer.append(samples).catch((error) => {
      console.error(`[meeting] could not write the ${track} track:`, error)
    })
  }

  const closeWriters = async () => {
    const results = new Map()
    for (const [track, writer] of writers) {
      results.set(track, await writer.close().catch((error) => {
        console.error(`[meeting] could not close the ${track} track:`, error)
        return null
      }))
    }
    writers = new Map()
    return results
  }

  const stop = async () => {
    if (state.status !== 'recording') return null

    const { title, startedAt, dir } = state
    const endedAt = Date.now()
    const closed = await closeWriters()
    console.log('[meeting] chunks received:', JSON.stringify([...chunkCounts]))

    const tracks = [...closed]
      .filter(([, result]) => result && result.seconds >= MEETING.minSeconds)
      .map(([track, result]) => ({
        track,
        speaker: TRACK_SPEAKERS[track],
        path: result.path,
        seconds: result.seconds,
        peak: result.peak,
        rms: result.rms,
        isSilent: result.rms < MEETING.silenceRms,
        isQuiet: result.rms < MEETING.quietRms,
      }))

    publish({ status: 'processing', title, startedAt, dir, step: 'Preparing…' })
    return { title, startedAt: new Date(startedAt), endedAt: new Date(endedAt), dir, tracks }
  }

  const progress = (step) => {
    if (state.status === 'processing') publish({ ...state, step })
  }

  const finish = ({ notePath, warnings }) =>
    publish({ status: 'idle', lastNote: notePath, warnings })

  const fail = (message) => publish({ status: 'error', message })

  const reset = () => publish({ status: 'idle' })

  return {
    start,
    stop,
    appendChunk,
    progress,
    finish,
    fail,
    reset,
    state: () => state,
    isRecording: () => state.status === 'recording',
  }
}

import { readdir, rm, stat } from 'node:fs/promises'
import { join } from 'node:path'
import { MEETING } from '../constants.js'
import { toDecibels } from './wav.js'
import { appendNote } from '../storage/notes.js'
import { TRACK_NAMES } from './session.js'
import { checkOllama } from './llm.js'
import { composeNote, writeNote, NOTE_FILE } from './note.js'
import { meetingsDir } from './paths.js'
import { mergeTracks, transcribeFile } from './transcribe.js'
import { summariseMeeting } from './summarise.js'

/**
 * Transcript first, summary second — and the note is written either way. A timestamped,
 * speaker-labelled transcript is already most of the value, so losing it because a
 * summariser was offline would be indefensible. Anything that failed is recorded in the
 * note itself rather than only in a log the user will never read.
 */
export const processMeeting = async ({ session, settings, onProgress, signal }) => {
  const { dir, title, startedAt, endedAt, tracks } = session
  const warnings = []

  if (tracks.length === 0) {
    warnings.push('No audio was captured. Check Screen Recording and Microphone permissions.')
  }

  // A silent track is dropped rather than transcribed: recognisers invent plausible
  // sentences out of silence, and invented content in a meeting record is worse than a
  // missing track.
  const silent = tracks.filter((track) => track.isSilent)
  for (const track of silent) {
    warnings.push(
      track.track === 'system'
        ? "The other participants' audio was silent: macOS system-audio capture returned " +
          'an empty stream. See "System audio" in the README.'
        : 'Your microphone was silent — check the input device and that nothing else has ' +
          'exclusive use of it.',
    )
  }

  const audible = tracks.filter((track) => !track.isSilent)
  for (const track of audible.filter((entry) => entry.isQuiet)) {
    warnings.push(
      `${capitalise(TRACK_NAMES[track.track])} audio was very quiet ` +
        `(${toDecibels(track.rms)} dB), so the transcript below may be unreliable.`,
    )
  }
  const transcripts = []
  for (const [index, track] of audible.entries()) {
    onProgress?.(`Transcribing ${track.speaker.toLowerCase()} (${index + 1}/${audible.length})…`)
    try {
      const result = await transcribeFile({
        wavPath: track.path,
        outputBase: join(dir, track.track),
        signal,
      })
      transcripts.push({ speaker: track.speaker, result })
    } catch (error) {
      console.error(`[meeting] ${track.track} transcription failed:`, error)
      warnings.push(
        `Could not transcribe the ${track.speaker.toLowerCase()} track: ${error.message}` +
          (error.hint ? ` — try: ${error.hint}` : ''),
      )
    }
  }

  const segments = mergeTracks(transcripts)
  const languages = [...new Set(transcripts.map((t) => t.result.language))].filter(
    (language) => language && language !== 'unknown',
  )

  let summary = null
  if (segments.length > 0) {
    onProgress?.('Summarising…')
    const model = settings.llmModel
    const llm = await checkOllama(model)

    if (!llm.ok) {
      warnings.push(`${llm.reason}${llm.hint ? ` — try: ${llm.hint}` : ''}`)
    } else {
      try {
        summary = await summariseMeeting({ model, segments, title, signal })
      } catch (error) {
        console.error('[meeting] summarising failed:', error)
        warnings.push(`Could not summarise: ${error.message}`)
      }
    }
  }

  onProgress?.('Writing the note…')
  const markdown = composeNote({
    title,
    startedAt,
    endedAt,
    languages,
    segments,
    summary,
    warnings,
  })
  const notePath = await writeNote({ dir, markdown })

  await linkFromDailyNote({ settings, title, startedAt, notePath, minutes: Math.round((endedAt - startedAt) / 60_000) })
  if (!settings.keepMeetingAudio) await discardAudio(tracks)

  return { notePath, warnings, segmentCount: segments.length }
}

const capitalise = (text) => text.charAt(0).toUpperCase() + text.slice(1)

/** A meeting the daily note does not mention is a meeting you will never find again. */
const linkFromDailyNote = async ({ settings, title, startedAt, notePath, minutes }) => {
  try {
    await appendNote({
      dataDir: settings.dataDir,
      at: startedAt,
      text: `Meeting: **${title || 'Untitled'}** (${minutes}m) — [[${notePath}]]`,
    })
  } catch (error) {
    console.warn('[meeting] could not link from the daily note:', error.message)
  }
}

const discardAudio = async (tracks) => {
  for (const track of tracks) {
    await rm(track.path, { force: true }).catch((error) =>
      console.warn(`[meeting] could not remove ${track.path}:`, error.message),
    )
  }
}

/** Newest first, for the panel's list. */
export const listRecentMeetings = async ({ dataDir, limit = 8 }) => {
  const dir = meetingsDir(dataDir)
  const entries = await readdir(dir, { withFileTypes: true }).catch(() => [])

  const folders = entries.filter((entry) => entry.isDirectory()).map((entry) => entry.name)
  const recent = folders.sort().reverse().slice(0, limit)

  return Promise.all(
    recent.map(async (name) => {
      const path = join(dir, name)
      const hasNote = await stat(join(path, NOTE_FILE)).then(
        () => true,
        () => false,
      )
      return { name, path, notePath: hasNote ? join(path, NOTE_FILE) : null }
    }),
  )
}

const bridge = window.recorder

const TRACKS = Object.freeze({ system: 'system', mic: 'mic' })

let context = null
let active = []

bridge.onBegin((options) => {
  begin(options).catch((error) => {
    console.error('[recorder] could not start:', error)
    bridge.status({ state: 'error', message: describe(error) })
    void end()
  })
})

bridge.onEnd(() => {
  end().catch((error) => console.error('[recorder] could not stop cleanly:', error))
})

/**
 * Two independent tracks rather than one mix: knowing which half of a meeting was you is
 * the difference between a transcript and a useful note.
 */
async function begin({ sampleRate, chunkFrames, withMic }) {
  await end()

  context = new AudioContext({ sampleRate })
  await context.audioWorklet.addModule('./pcmWorklet.js')

  const system = await captureSystemAudio()
  const mic = withMic ? await captureMicrophone() : null

  if (!system && !mic) throw new Error('No audio source could be opened.')

  // Zero gain keeps the graph alive without playing the meeting back into itself.
  const sink = new GainNode(context, { gain: 0 })
  sink.connect(context.destination)

  if (system) active.push(tap(system, TRACKS.system, chunkFrames, sink))
  if (mic) active.push(tap(mic, TRACKS.mic, chunkFrames, sink))

  bridge.status({
    state: 'recording',
    tracks: active.map((entry) => entry.track),
    sampleRate: context.sampleRate,
  })
}

async function captureSystemAudio() {
  try {
    // The main process answers this with { video: <screen>, audio: 'loopback' }; the video
    // track is required to open the ScreenCaptureKit stream but is of no use to us.
    const stream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: true })
    for (const track of stream.getVideoTracks()) track.stop()

    if (stream.getAudioTracks().length === 0) {
      console.warn('[recorder] system audio returned no track — check screen recording permission')
      return null
    }
    return stream
  } catch (error) {
    console.warn('[recorder] system audio unavailable:', describe(error))
    return null
  }
}

async function captureMicrophone() {
  try {
    return await navigator.mediaDevices.getUserMedia({
      // The other side already arrives on its own track, so cancellation would only
      // carve holes in our own voice.
      audio: { echoCancellation: false, noiseSuppression: true, autoGainControl: true },
    })
  } catch (error) {
    console.warn('[recorder] microphone unavailable:', describe(error))
    return null
  }
}

function tap(stream, track, chunkFrames, sink) {
  const source = new MediaStreamAudioSourceNode(context, { mediaStream: stream })
  const node = new AudioWorkletNode(context, 'pcm-collector', {
    processorOptions: { chunkFrames },
  })

  node.port.onmessage = (event) => bridge.chunk(track, event.data)
  source.connect(node)
  node.connect(sink)

  return { track, stream, source, node }
}

async function end() {
  for (const entry of active) {
    entry.node.port.onmessage = null
    entry.node.disconnect()
    entry.source.disconnect()
    for (const track of entry.stream.getTracks()) track.stop()
  }
  active = []

  if (context) {
    await context.close().catch(() => {})
    context = null
  }
}

const describe = (error) => (error instanceof Error ? error.message : String(error))
